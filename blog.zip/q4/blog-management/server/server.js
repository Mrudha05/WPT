const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

let blogs = [];
let nextId = 1;

app.use(bodyParser.json());
app.use(express.static('../client'));

app.post('/api/blogs', (req, res) => {
    const { blogName, postDate, blogContent } = req.body;
    const newBlog = {
        id: nextId++,
        blogName,
        postDate,
        blogContent
    };
    blogs.push(newBlog);
    res.status(201).json(newBlog);
});

app.get('/api/blogs', (req, res) => {
    res.json(blogs);
});

app.delete('/api/blogs/:id', (req, res) => {
    const id = parseInt(req.params.id, 10);
    blogs = blogs.filter(blog => blog.id !== id);
    res.status(204).end();
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
