import React,{useState} from 'react';

const TaskList = () =>
{
    const [taskName,setTaskname]=useState("")
    const [duration,setDuration]=useState("")
    const [tasks,setTasks]=useState([])

    const handleSubmit=(e)=>{
        e.preventDefault()
        console.log(taskName,duration)
        setTasks([...tasks,{taskName,duration}])

        setDuration("")
        setTaskname("")

    }

    return(
        <div>
            <form onSubmit={handleSubmit}>
            <label>Task Name :</label>
            <input type="text" name="tm" value={taskName} onChange={(e)=>setTaskname(e.target.value)} />
            <label>Duration</label>
            <input type="text" name="td" value={duration} onChange={(e)=>setDuration(e.target.value)} />
            <button type="submit">Add List</button>
            </form>
            <table>
                <thead>
                <tr>
                    <th>TaskName</th>
                    <th>Task Duration</th>
                </tr>
                </thead>
                <tbody>
            
                    {tasks.map((task,index)=>(
                    <tr key={index}>
                        <td>{task.taskName}</td>
                        <td>{task.duration}</td>
                        </tr>))}
                
                </tbody>
            </table>
        </div>
    )
}

export default TaskList;