import logo from './logo.svg';
import './App.css';
import React,{useState} from 'react';
import AddUser from './components/AddUser';
import UserList from './components/userList';

function App() {
  const [users, setUsers] = useState([]);

  const Auser=(user) =>
  {
    setUsers([...users,user]);
  }
  return (
    <div>
      <h1>User Managament System</h1>
      <AddUser user={Auser} />
      <UserList users={users} />
    </div>
  );
}

export default App;
