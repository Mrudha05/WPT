import React,{useState} from 'react';
import axios from 'axios';

const AddUser = ({user}) =>
{
    const [userName, setUsername] = useState("");
   
    const [gender, setGender] =useState("Male");
    const [dob,setDob] = useState("");

    

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!userName || !gender || !dob) return;
    
        try {
          const response = await axios.post('http://localhost:3000/new', {
            userName,
            gender,
            dob,
          });
          user(response.data.user);
          setUsername('');
          setGender('Male');
          setDob('');
        } catch (error) {
          console.error('There was an error adding the user!', error);
        }
      };
    

    const handleDateChange=(e)=>
    {
        const selectedDate =e.target.value;
        setDob(selectedDate);
    }


    return(
        <form onSubmit={handleSubmit}>
            <label>Enter User Name:</label>
            <input type="text" value={userName} onChange={(e)=>setUsername(e.target.value)}/>
            <br/>
            <label>Gender:</label>
            <select value={gender} onChange={(e)=>setGender(e.target.value)}>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
            </select>
            <br/>
            <label>Date of Birth:</label>
            <input type="date" value={dob} onChange={handleDateChange}/>
            <button type="submit">Submit</button>
        </form>
    )

}
export default AddUser;
