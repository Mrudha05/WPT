$(document).ready(function() {
    $('#categorySelect').change(function() {
      var selectedCategory = $(this).val();
      $('#imageContainer').empty(); // Clear previous images
  
      if (selectedCategory === 'groceries') {
        // Display groceries images
        displayImages(['images/rice.jpg', 'images/dal.jpg']);
      } else if (selectedCategory === 'beverages') {
        // Display beverages images
        displayImages(['images/water.jpg', 'images/tea.jpg', 'images/coffee.jpg']);
      } else if (selectedCategory === 'other') {
        // Display other images
        displayImages(['images/chips.jpg', 'images/pizza.jpg']);
      }
    });
  
    function displayImages(images) {
      var container = $('#imageContainer');
      $.each(images, function(index, image) {
        var imgElement = $('<div class="col-md-4 mb-3"><img src="' + image + '" class="img-fluid"></div>');
        container.append(imgElement);
      });
    }
  });
  