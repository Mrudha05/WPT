import React, { useState, useEffect } from 'react';

const ProductForm = () => {
  // State to manage form inputs and validation errors
  const [productId, setProductId] = useState('');
  const [productName, setProductName] = useState('');
  const [price, setPrice] = useState('');
  const [unitOfMeasurement, setUnitOfMeasurement] = useState('');
  const [formErrors, setFormErrors] = useState({
    productId: '',
    productName: '',
    price: '',
    unitOfMeasurement: ''
  });
  const [isFormValid, setIsFormValid] = useState(false);

  // Function to validate the form inputs
  const validateForm = () => {
    let valid = true;
    const errors = {
      productId: '',
      productName: '',
      price: '',
      unitOfMeasurement: ''
    };

    if (!productId.trim()) {
      errors.productId = 'Product ID cannot be blank';
      valid = false;
    }
    if (productName.length < 4) {
      errors.productName = 'Product Name must be at least 4 characters';
      valid = false;
    }
    if (isNaN(price) || +price <= 0) {
      errors.price = 'Price must be a number greater than 0';
      valid = false;
    }
    if (!['dozen', 'per price', 'kg'].includes(unitOfMeasurement)) {
      errors.unitOfMeasurement = 'Unit of Measurement must be dozen, per price, or kg';
      valid = false;
    }

    setFormErrors(errors);
    return valid;
  };

  // Update isFormValid based on form validation
  useEffect(() => {
    setIsFormValid(validateForm());
  }, [productId, productName, price, unitOfMeasurement]);

  // Function to handle form submission
  const handleSubmit = (event) => {
    event.preventDefault();
    if (validateForm()) {
      // Handle form submission logic here
      console.log('Form is valid, submitting...');
    } else {
      console.log('Form has errors, cannot submit.');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label htmlFor="productId">Product ID:</label>
        <input
          type="text"
          id="productId"
          value={productId}
          onChange={(e) => setProductId(e.target.value)}
        />
        {formErrors.productId && <span>{formErrors.productId}</span>}
      </div>

      <div>
        <label htmlFor="productName">Product Name:</label>
        <input
          type="text"
          id="productName"
          value={productName}
          onChange={(e) => setProductName(e.target.value)}
        />
        {formErrors.productName && <span>{formErrors.productName}</span>}
      </div>

      <div>
        <label htmlFor="price">Price:</label>
        <input
          type="number"
          id="price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
        />
        {formErrors.price && <span>{formErrors.price}</span>}
      </div>

      <div>
        <label htmlFor="unitOfMeasurement">Unit of Measurement:</label>
        <select
          id="unitOfMeasurement"
          value={unitOfMeasurement}
          onChange={(e) => setUnitOfMeasurement(e.target.value)}
        >
          <option value="">Select...</option>
          <option value="dozen">dozen</option>
          <option value="per price">per price</option>
          <option value="kg">kg</option>
        </select>
        {formErrors.unitOfMeasurement && <span>{formErrors.unitOfMeasurement}</span>}
      </div>

      <button type="submit" disabled={!isFormValid}>
        Submit
      </button>
    </form>
  );
};

export default ProductForm;
